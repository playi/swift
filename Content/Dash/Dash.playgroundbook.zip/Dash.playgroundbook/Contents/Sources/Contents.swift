//
//import PlaygroundBluetooth
//import PlaygroundSupport
//import CoreBluetooth
//import UIKit
//
////let uuids: [CBUUID] = [CBUUID(string: "<UUID-Here>")]
//let centralManager = PlaygroundBluetoothCentralManager(services: nil, allowsMultipleConnections: false, queue: .global())
//
//var connectedPeripheral: CBPeripheral?
//
//class CentralManagerDelegate: PlaygroundBluetoothCentralManagerDelegate {
//    public func centralManagerStateDidChange(_ centralManager: PlaygroundBluetoothCentralManager) {
//        // Handle Bluetooth state changes.
//    }
//    
//    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDiscover peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?, rssi: Double)  {
//        // Handle peripheral discovery.
//    }
//    
//    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, willConnectTo peripheral: CBPeripheral) {
//        // Handle peripheral connection attempts (prior to connection being made).
//    }
//    
//    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didConnectTo peripheral: CBPeripheral) {
//        // Handle successful peripheral connection.
//        connectedPeripheral = peripheral
//    }
//    
//    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didFailToConnectTo peripheral: CBPeripheral, error: Error?) {
//        // Handle failed peripheral connection.
//    }
//    
//    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDisconnectFrom peripheral: CBPeripheral, error: Error?) {
//        // Handle peripheral disconnection.
//        connectedPeripheral = nil
//    }
//}
//
//let delegate = CentralManagerDelegate()
//centralManager.delegate = delegate
//
//class ConnectionViewDelegate: PlaygroundBluetoothConnectionViewDelegate, PlaygroundBluetoothConnectionViewDataSource {
//    // MARK: PlaygroundBluetoothConnectionViewDataSource
//    
//    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, itemForPeripheral peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?) -> PlaygroundBluetoothConnectionView.Item {
//        // Provide display information associated with a peripheral item.
//        let name = peripheral.name ?? "Unknown Device"
//        let icon = #imageLiteral(resourceName: "Photo 4-17-17 at 11.24 AM.jpg")
//        let issueIcon = icon
//        return PlaygroundBluetoothConnectionView.Item(name: name, icon: icon, issueIcon: issueIcon, firmwareStatus: nil, batteryLevel: nil)
//    }
//    
//    // MARK: PlaygroundBluetoothConnectionView Delegate
//    
//    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, shouldDisplayDiscovered peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?, rssi: Double) -> Bool {
//        // Filter out peripheral items (optional)
//        return peripheral.name != nil
//    }
//    
//    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, titleFor state: PlaygroundBluetoothConnectionView.State) -> String {
//        // Provide a localized title for the given state of the connection view.
//        switch state {
//        case .noConnection:
//            return "Connect Robot"
//        case .connecting:
//            return "Connecting Robot"
//        case .multipleConnections:
//            let numConnected = centralManager.connectedPeripherals.count
//            return "\(numConnected) Robots"
//        case .searchingForPeripherals:
//            return "Searching for Robot"
//        case .selectingPeripherals:
//            return "Select Robot"
//        case .connectedPeripheralFirmwareOutOfDate:
//            return "Connect to a Different Robot"
//        }
//    }
//    
//    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, firmwareUpdateInstructionsFor peripheral: CBPeripheral) -> String {
//        // Provide firmware update instructions.
//        return "Firmware update instructions here."
//    }
//}
//
//let view = PlaygroundBluetoothConnectionView(centralManager: centralManager)
//let viewDelegate = ConnectionViewDelegate()
//view.delegate = viewDelegate
//view.dataSource = viewDelegate
//
//let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 250, height: 250))
//containerView.isUserInteractionEnabled = true
//containerView.backgroundColor = UIColor.gray
//let vc = view.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20)
//let hc = view.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -20)
//containerView.addSubview(view)
//NSLayoutConstraint.activate([vc, hc])
//
//PlaygroundPage.current.liveView = containerView
