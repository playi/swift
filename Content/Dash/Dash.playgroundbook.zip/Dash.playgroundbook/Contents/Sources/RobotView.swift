//
//  RobotView.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/10/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import UIKit
import Foundation
import CoreBluetooth

public class RobotView:UIView{
    
    var scrollView:UIScrollView!
    var buttons = [UIButton]()
    let label = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    let icon = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    
    var scrollViewConstraints = [NSLayoutConstraint]()
    var labelConstraints = [NSLayoutConstraint]()
    var iconConstraints = [NSLayoutConstraint]()
    
    var robotName:String = ""
    var isLandscapeView = false;
    
    override init (frame : CGRect) {
        super.init(frame : frame)
        isLandscapeView = (frame.width > frame.height)
        setupView()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setupView(){
        icon.image = #imageLiteral(resourceName: "robotAvatar.png")
        icon.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(icon)
        
        label.numberOfLines = 0
        label.text = NSLocalizedString("Robots\nAvailable", comment: "")
        label.textAlignment = NSTextAlignment.left;
        label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(label)
        
        scrollView = UIScrollView(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        scrollView.backgroundColor = #colorLiteral(red: 0.9688462615, green: 0.9830557704, blue: 1, alpha: 0)
        scrollView.contentSize = CGSize(width:200, height:50)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(scrollView)
        
        if(isLandscapeView){
            updateLandscapeView()
        }
        else{
            updatePortraitView()
        }
    }
    
    public func updateLandscapeView(){
        isLandscapeView = true;
        if(self.robotName == ""){
            scrollView.frame = CGRect(x: 0, y: 0, width: 200, height: 50)
            scrollView.contentSize = CGSize(width:200, height:50)
            
            NSLayoutConstraint.deactivate(iconConstraints)
            iconConstraints.removeAll()
            iconConstraints.append(icon.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20))
            iconConstraints.append(icon.widthAnchor.constraint(equalToConstant:50))
            iconConstraints.append(icon.heightAnchor.constraint(equalToConstant:50))
            iconConstraints.append(icon.topAnchor.constraint(equalTo: self.topAnchor, constant: 20))
            NSLayoutConstraint.activate(iconConstraints)
            
            NSLayoutConstraint.deactivate(labelConstraints)
            labelConstraints.removeAll()
            labelConstraints.append(label.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 20))
            labelConstraints.append(label.widthAnchor.constraint(equalToConstant:75))
            labelConstraints.append(label.heightAnchor.constraint(equalToConstant:50))
            labelConstraints.append(label.topAnchor.constraint(equalTo: self.topAnchor, constant: 20))
            NSLayoutConstraint.activate(labelConstraints)
            
            NSLayoutConstraint.deactivate(scrollViewConstraints)
            scrollViewConstraints.removeAll()
            scrollViewConstraints.append(scrollView.leadingAnchor.constraint(equalTo: label.trailingAnchor, constant: 20))
            scrollViewConstraints.append(scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20))
            scrollViewConstraints.append(scrollView.widthAnchor.constraint(greaterThanOrEqualToConstant:200))
            scrollViewConstraints.append(scrollView.heightAnchor.constraint(equalToConstant:50))
            scrollViewConstraints.append(scrollView.topAnchor.constraint(equalTo: self.topAnchor, constant: 20))
            NSLayoutConstraint.activate(scrollViewConstraints)
            
            var index:Int = 0
            for button in self.buttons {
                button.frame = CGRect(x:index*100 , y: 0, width: 100, height: 50)
                index += 1
            }
        }
        else{
            label.textAlignment = NSTextAlignment.right;
            
            NSLayoutConstraint.deactivate(iconConstraints)
            iconConstraints.removeAll()
            iconConstraints.append(icon.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20))
            iconConstraints.append(icon.widthAnchor.constraint(equalToConstant:50))
            iconConstraints.append(icon.heightAnchor.constraint(equalToConstant:50))
            iconConstraints.append(icon.topAnchor.constraint(equalTo: self.topAnchor, constant: 20))
            NSLayoutConstraint.activate(iconConstraints)
            
            NSLayoutConstraint.deactivate(labelConstraints)
            labelConstraints.removeAll()
            labelConstraints.append(label.trailingAnchor.constraint(equalTo: icon.leadingAnchor, constant: -10))
            labelConstraints.append(label.widthAnchor.constraint(equalToConstant:150))
            labelConstraints.append(label.heightAnchor.constraint(equalToConstant:50))
            labelConstraints.append(label.topAnchor.constraint(equalTo: self.topAnchor, constant: 20))
            NSLayoutConstraint.activate(labelConstraints)
        }
    }
    
    public func updatePortraitView(){
        isLandscapeView = false
        scrollView.frame = CGRect(x: 0, y: 0, width: 100, height: 375)
        scrollView.contentSize = CGSize(width:100, height:375)
        label.textAlignment = NSTextAlignment.left;
        
        NSLayoutConstraint.deactivate(iconConstraints)
        iconConstraints.removeAll()
        iconConstraints.append(icon.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20))
        iconConstraints.append(icon.widthAnchor.constraint(equalToConstant:50))
        iconConstraints.append(icon.heightAnchor.constraint(equalToConstant:50))
        iconConstraints.append(icon.topAnchor.constraint(equalTo: self.topAnchor, constant: 75))
        NSLayoutConstraint.activate(iconConstraints)
        
        NSLayoutConstraint.deactivate(labelConstraints)
        labelConstraints.removeAll()
        labelConstraints.append(label.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20))
        labelConstraints.append(label.widthAnchor.constraint(equalToConstant:150))
        labelConstraints.append(label.heightAnchor.constraint(equalToConstant:50))
        labelConstraints.append(label.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 10))
        NSLayoutConstraint.activate(labelConstraints)
        
        NSLayoutConstraint.deactivate(scrollViewConstraints)
        scrollViewConstraints.removeAll()
        scrollViewConstraints.append(scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20))
        scrollViewConstraints.append(scrollView.widthAnchor.constraint(greaterThanOrEqualToConstant:100))
        scrollViewConstraints.append(scrollView.heightAnchor.constraint(equalToConstant:375))
        scrollViewConstraints.append(scrollView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 10))
        NSLayoutConstraint.activate(scrollViewConstraints)
        
        var index:Int = 0
        for button in self.buttons {
            button.frame = CGRect(x:0 , y: index*50, width: 100, height: 50)
            index += 1
        }
    }
    
    public func updateConnecttedRobot(_ name:String){
        self.robotName = name
        label.text = NSLocalizedString("Connected \nto ", comment: "")
        label.text = label.text!+name
        scrollView.isHidden = true
        if(isLandscapeView){
            updateLandscapeView()
        }
        else{
            updatePortraitView()
        }
    }
    
    public func addDiscoveredRobot(_ name:String){
        print("addDiscoveredRobot: \(name)")
        let button = UIButton(frame: CGRect(x:self.buttons.count*100 , y: 0, width: 150, height: 50))
//        button.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "robotNameBg.png")) // # imageLiteral(resourceName: "robotNameBg.png")
        button.setTitle(name, for: UIControlState.normal)
        button.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: UIControlState.normal)
        button.titleLabel!.font = UIFont.boldSystemFont(ofSize: 15)
        button.titleLabel!.textAlignment = .left
        button.titleLabel!.lineBreakMode = .byWordWrapping
        button.titleLabel!.numberOfLines = 2
        scrollView.addSubview(button)
        self.buttons.append(button)
    }
    
    func onButtonClicked(_ button: UIButton){
        //Do something
    }

}

