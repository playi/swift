/*:#localized(key: "FirstProseBlock")
 **Goal:** Use Dash’s distance sensors to check for obstacles.
 
 Gotta nail the fundamentals to be a winner.
 
 Dramatically place a hand or object in front of Dash to make this scene of the story more engaging.
 
 Add to the code below using another **if statement**, **boolean**, and **motion** command. Program Dash to fire up the engines when there’s an **obstacle in front** and then leap out of the gate (**moves forward**) when the obstacle is gone.

 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, if)
//#-code-completion(identifier, show, ==, break, true, false, isObstacleInFront(), isObstacleInRear(), moveForward(), moveBackward())
//#-hidden-code
setup()
//#-end-hidden-code
while true{
    if (isObstacleInFront() == true) {
        playSound(SoundType.CarEngine)
        break
    }
}

while true{
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
//#-hidden-code
exitProgram()
//#-end-hidden-code
