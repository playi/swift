/*:#localized(key: "FirstProseBlock")

 The races are over but you’ve just gotten started! What story can you tell with Dash as the main character?

 Here are a few criteria for your story:
 - Dash should move to at least two different places/settings.
 - Dash should communicate in at least two different ways.
 - Be sure to use loops and if statements to make your story more interesting.
 
 Write code, build a set, and even dress up Dash and watch Dash be the star in your story.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), moveBackward(), turnLeft(), turnRight(), waitForObstacleInFront(), waitForObstacleInRear(), waitForButton1Press(), waitForButton2Press(), waitForButton3Press(), waitForClap(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo, setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
//#-end-hidden-code

//#-editable-code Tap to enter code
//#-end-editable-code

//#-hidden-code
exitProgram()
//#-end-hidden-code
