/*:#localized(key: "FirstProseBlock")
 **Goal:** Drive Dash along the path.
 
 It’s race day and Dash needs to get to the big event.
 
 Establish the setting of the story by programming Dash to navigate the map.
 
 Use your Swift programming skills to control Dash with **basic motion** function calls like `moveForward()`, `turnRight()`, and `turnLeft()`.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), turnLeft(), moveBackward(), turnRight())
//#-hidden-code 
setup()
//#-end-hidden-code
moveForward()
//#-editable-code Tap to enter code
//#-end-editable-code
moveForward()
//#-hidden-code
exitProgram()
/*
 turnRight()
 moveForward()
 turnLeft()
 moveForward()
 turnLeft()
 moveForward()
 moveForward()
 turnRight()
 moveForward()
 turnRight()
 moveForward()
 turnLeft()
 */
//#-end-hidden-code
