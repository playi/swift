/*:#localized(key: "FirstProseBlock")
 **Goal:** Drive Dash around the track.

 No refunds on Race day! Dash needs to loosen up the wheels.
 
 Ready to roll?
 
 Define the `driveLap()` function that gets called below to take a warmup lap.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), turnLeft(), moveBackward(), turnRight())
//#-hidden-code
setup()
//#-end-hidden-code

func driveLap() {
//#-editable-code Tap to enter code
//#-end-editable-code
}

driveLap()

//#-hidden-code
exitProgram()
/*
 moveForward()
 moveForward()
 turnLeft()
 moveForward()
 turnLeft()
 moveForward()
 moveForward()
 turnLeft()
 moveForward()
 */
//#-end-hidden-code
