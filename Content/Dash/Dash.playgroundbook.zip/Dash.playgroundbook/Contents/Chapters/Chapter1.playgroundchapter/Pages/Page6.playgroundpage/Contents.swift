/*:#localized(key: "FirstProseBlock")
 **Goal:** Program Dash to wait for the signals.

 Dash is raring to go!
 
 Program Dash to leap out of the gate (**move forward**) after two starting signals: a green **light** and then a clap **sound detection** using the `clapHeard()` function. Use an **if statement** to check whether the clap is heard.
 
 - example:\
 `  if(clapHeard() == true){`\
 `      playSound(SoundType.Hi)`\
 `  }`
 
 See all available [color](glossary://ColorType) commands.
 
 Each scene in the story has led to this main event and you have control over the clap signal. Add to the suspense by waiting extra long to perform the clap.

 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, if)
//#-code-completion(identifier, show, ==, true, false, clapHeard(), moveForward(), setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
//#-end-hidden-code
playSound(SoundType.CarEngine)
setLight(ColorType.Red)
setLight(ColorType.Yellow)
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
exitProgram()
/*
 setLight(ColorType.Green)
 waitForClap()
 moveForward()
 */
//#-end-hidden-code
