/*:#localized(key: "FirstProseBlock")
 **Goal:** Use a loop to drive Dash through the race.

 Lap it up using a **for loop**! This course has three laps.
 
 Help build excitement on each new lap by acting as the commentator for the race.

 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for)
//#-code-completion(identifier, show, driveLap())
//#-hidden-code
setup()
//#-end-hidden-code

func driveLap() {
    moveForward()
    moveForward()
    turnLeft()
    moveForward()
    turnLeft()
    moveForward()
    moveForward()
    turnLeft()
    moveForward()
}

//#-editable-code Tap to enter code
//#-end-editable-code

//#-hidden-code
exitProgram()
/*
 for i in 1...3 {
    driveLap()
 }
 */
//#-end-hidden-code
