/*:#localized(key: "FirstProseBlock")
 Dash needs fast reflexes to win the race.
 
 **Goal:** program Dash’s distance sensors to react to an obstacle.
 
 Take a look at the code below. If there is an **obstacle in front**, Dash will play the **car engine sound**.
 
 Now add another **if statement**, **boolean**, and **motion command** in order to make Dash move forward when the obstacle is removed.
 
 After writing your code, test it out. Put an object in front of Dash, then run the program. Dash should play the car engine sound. Then, as soon as you remove the object, Dash should move forward.

 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, if)
//#-code-completion(identifier, show, ==, break, true, false, isObstacleInFront(), isObstacleInRear(), moveForward(), moveBackward())
//#-hidden-code
setup()
//#-end-hidden-code
while true{
    if (isObstacleInFront() == true) {
        playSound(SoundType.CarEngine)
        break
    }
}

while true{
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
//#-hidden-code
exitProgram()
//#-end-hidden-code
