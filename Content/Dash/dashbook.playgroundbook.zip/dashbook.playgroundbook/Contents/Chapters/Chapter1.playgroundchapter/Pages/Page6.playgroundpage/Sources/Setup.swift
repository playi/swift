import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


var delegate: UserProcessDelegate?
let commandSender:CommandSender = CommandSender()

public func setup(){
    let page = PlaygroundPage.current
    page.needsIndefiniteExecution = true
    let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
    delegate = UserProcessDelegate(pauseHandler: commandSender)
    delegate?.onAssessment = assessment
    proxy?.delegate = delegate
}

public func assessment(_ playgroundValue:PlaygroundValue)->Bool{
    // Assessment
    var correctSolution:[CommandType] = [
        CommandType.COMMAND_SOUND_ENGINE,
        CommandType.COMMAND_LIGHT_RED,
        CommandType.COMMAND_LIGHT_YELLOW,
        CommandType.COMMAND_LIGHT_GREEN,
        CommandType.COMMAND_WAITFOR_CLAP,
        CommandType.COMMAND_MOVE_FORWARD,
    ]
    var commands:[PlaygroundValue] = [PlaygroundValue]()
    if case let .array(values) = playgroundValue {
        commands = values
    }
    let result:Bool = RobotCommand.solutionChecker(commands, correctSolution)
    //Hints
    var failureHints = [
        NSLocalizedString("Don’t let Dash start moving until the **lights** are green and a loud clap **sound** is heard.", comment: "")
    ]
//    var solutionHint = "waitForObstacleInFront()\nplaySoundCarEngine()"
//    solutionHint = "```swift\n\(solutionHint)\n```"
    //Update assessment status
    if(result){
        PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### And they’re off! \n Now for the some athletic activity... \n\n[**Next Page**](@next)", comment: ""))
    }
    else{
        PlaygroundPage.current.assessmentStatus = .fail(hints: failureHints, solution: nil)
    }
    return result
}
