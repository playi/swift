/*:#localized(key: "FirstProseBlock")
 It’s race day! Dash is competing and needs to get to the big event.
 
 **Goal:** program Dash to drive along the path.
 
 Help Dash navigate the path by using **basic motion** function calls like `moveForward()`, `turnRight()`, and `turnLeft()`.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), turnLeft(), moveBackward(), turnRight())
//#-hidden-code 
setup()
//#-end-hidden-code
moveForward()
//#-editable-code Tap to enter code
//#-end-editable-code
moveForward()
//#-hidden-code
exitProgram()
/*
 turnRight()
 moveForward()
 turnLeft()
 moveForward()
 turnLeft()
 moveForward()
 moveForward()
 turnRight()
 moveForward()
 turnRight()
 moveForward()
 turnLeft()
 */
//#-end-hidden-code
