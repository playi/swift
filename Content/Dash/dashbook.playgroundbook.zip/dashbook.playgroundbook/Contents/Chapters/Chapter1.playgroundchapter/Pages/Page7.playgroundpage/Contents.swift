/*:#localized(key: "FirstProseBlock")
 This is big moment! Three laps to win the race!
 
 **Goal:** program Dash to drive through the racecourse three times.  Can you do it using `driveLap()` only once?  Try using a **for loop**.
 
 
 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for)
//#-code-completion(identifier, show, driveLap())
//#-hidden-code
setup()
//#-end-hidden-code

func driveLap() {
    moveForward()
    moveForward()
    turnLeft()
    moveForward()
    turnLeft()
    moveForward()
    moveForward()
    turnLeft()
    moveForward()
    turnLeft()
}

//#-editable-code Tap to enter code
//#-end-editable-code

//#-hidden-code
exitProgram()
/*
 for i in 1...3 {
    driveLap()
 }
 */
//#-end-hidden-code
