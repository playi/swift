/*:#localized(key: "FirstProseBlock")
 Dash brought home the win! That could only mean one thing: it’s time for a victory dance!
 
 **Goal:** create your own dance for Dash.
 
 Define your own `dance()` function below. Use as many robot actions as possible. Be creative!

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), moveBackward(), turnLeft(), turnRight(), waitForObstacleInFront(), waitForObstacleInRear(), waitForButton1Press(), waitForButton2Press(), waitForButton3Press(), waitForClap(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo, setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
//#-end-hidden-code

func dance() {
//#-editable-code Tap to enter code
//#-end-editable-code
}

dance()

//#-hidden-code
exitProgram()
/*
 playSound(SoundType.Bragging)
 playSound(SoundType.HereICome)
 playSound(SoundType.Interesting)
 playSound(SoundType.Inputs)
 playSound(SoundType.Horn)
 playSound(SoundType.Wha)
 playSound(SoundType.Awesome)
 playSound(SoundType.CarEngine)
 playSound(SoundType.Hi)
 playSound(SoundType.Fantastic)
 playSound(SoundType.OhNo)
 
 moveForward()
 moveBackward()
 turnLeft()
 turnRight()
 setLight(ColorType.Red)
 setLight(ColorType.Green)
 setLight(ColorType.Blue)
 setLight(ColorType.Yellow)
 setLight(ColorType.White)
 waitForObstacleInFront()
 setLight(ColorType.Red)
 waitForObstacleInRear()
 setLight(ColorType.Green)
 waitForButton1Press()
 setLight(ColorType.Red)
 waitForButton2Press()
 setLight(ColorType.Green)
 waitForButton3Press()
 setLight(ColorType.Red)
 waitForClap()
 setLight(ColorType.Green)
 */
//#-end-hidden-code
