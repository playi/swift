/*:#localized(key: "FirstProseBlock")
 # Wake up, it’s race day!
 **Goal:** Connect your Dash robot.
 
 To start programming Dash, turn on Bluetooth, look for the name of your robot in the Robots Available list, and type that name in the `connectToRobot()` function below. Then tap Run My Code.
 
*/

//#-code-completion(everything, hide)

//#-hidden-code
setup()
//#-end-hidden-code

connectToRobot(/*#-editable-code Tap to enter name*/""/*#-end-editable-code*/)

//#-hidden-code
exitProgram()
//#-end-hidden-code
