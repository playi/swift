import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


var delegate: UserProcessDelegate?
let commandSender:CommandSender = CommandSender()

public func setup(){
    let page = PlaygroundPage.current
    page.needsIndefiniteExecution = true
    let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
    delegate = UserProcessDelegate(pauseHandler: commandSender)
    delegate?.onAssessment = assessment
    proxy?.delegate = delegate
}

public func assessment(_ playgroundValue:PlaygroundValue)->Bool{
    let result:Bool = true
    //Hints
    var failureHints = [
        NSLocalizedString("Use your new **if statement** to check if `isObstacleInFront()` is `false`. ", comment: "")
    ]
//    var solutionHint = "waitForObstacleInFront()\nplaySoundCarEngine()"
//    solutionHint = "```swift\n\(solutionHint)\n```"
    //Update assessment status
    if(result){
        PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### Better safe than sorry! \n Time to meet the other competitors. \n\n[**Next Page**](@next)", comment: ""))
    }
    else{
        PlaygroundPage.current.assessmentStatus = .fail(hints: failureHints, solution: nil)
    }
    return result
}
