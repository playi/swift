/*:#localized(key: "FirstProseBlock")
 **Goal:** Trigger sounds with Dash’s buttons.
 
 Let the competition know you’ve arrived!
 
 Help your audience imagine other characters using Dash’s voice.
 
 Program Dash to greet each opponent with **sound** after a **button press** detection. Use Button 1 to initiate the greeting to Dash’s left and Button 2 for the greeting to Dash’s right.
 
 Use `playSound(SoundType.Hi)`for each greeting and detect **button presses** on the top of Dash’s head using the following functions:
 
 `waitForButton1Press()`
 
 `waitForButton2Press()`
 
 See all available [sound](glossary://SoundType) commands.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, waitForButton1Press(), waitForButton2Press(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo)
//#-hidden-code
setup()
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
turnLeft()
//#-editable-code Tap to enter code
//#-end-editable-code

//#-editable-code Tap to enter code
//#-end-editable-code
turnRight()
turnRight()
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
exitProgram()
//#-end-hidden-code
