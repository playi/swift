/*:#localized(key: "FirstProseBlock")
 Let’s make this a friendly race by greeting the other racers.
 
 **Goal:** program Dash’s buttons to trigger sounds.
 
 Use Button 1 to make Dash turn to the racer on the left and greet them, then use Button 2 to make Dash turn to the racer on the right and greet them.
 
 Use `playSound(SoundType.Hi)` for each greeting. To make Dash respond to **button presses**, use these functions:
 
 `waitForButton1Press()`
 
 `waitForButton2Press()`
 
 See all available [sound](glossary://SoundType) commands.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, waitForButton1Press(), waitForButton2Press(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo)
//#-hidden-code
setup()
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
turnLeft()
//#-editable-code Tap to enter code
//#-end-editable-code

//#-editable-code Tap to enter code
//#-end-editable-code
turnRight()
turnRight()
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
exitProgram()
//#-end-hidden-code
