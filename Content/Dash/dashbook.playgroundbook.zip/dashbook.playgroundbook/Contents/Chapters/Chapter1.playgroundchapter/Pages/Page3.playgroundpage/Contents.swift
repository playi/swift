/*:#localized(key: "FirstProseBlock")
 Dash’s motors need a warm-up before the big race.
 
 **Goal:** program Dash to drive once around the track.
 
 Define the `driveLap()` function below using **basic motion** commands in order to program Dash to drive one lap around the track.

 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), turnLeft(), moveBackward(), turnRight())
//#-hidden-code
setup()
//#-end-hidden-code

func driveLap() {
//#-editable-code Tap to enter code
//#-end-editable-code
}

driveLap()

//#-hidden-code
exitProgram()
/*
 moveForward()
 moveForward()
 turnLeft()
 moveForward()
 turnLeft()
 moveForward()
 moveForward()
 turnLeft()
 moveForward()
 */
//#-end-hidden-code
