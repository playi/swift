import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth



let robotViewController:RobotViewController = RobotViewController(5)
PlaygroundPage.current.liveView = robotViewController
