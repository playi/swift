import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


var delegate: UserProcessDelegate?
let commandSender:CommandSender = CommandSender()

public func setup(){
    let page = PlaygroundPage.current
    page.needsIndefiniteExecution = true
    let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
    delegate = UserProcessDelegate(pauseHandler: commandSender)
    delegate?.onAssessment = assessment
    proxy?.delegate = delegate
}

public func assessment(_ playgroundValue:PlaygroundValue)->Bool{
    // Assessment
    var name:String = ""
    if case let .array(commands) = playgroundValue {
        if commands.count > 0{
            if case let .dictionary(dict) = commands[0]{
                if dict[CommandType.COMMAND_CONNECT_ROBOT.rawValue] != nil{
                    if case let .string(text) = dict[CommandType.COMMAND_CONNECT_ROBOT.rawValue]! {
                        name = text
                    }
                }
            }
        }
    }
    //Hints
    let hints = [
        "Can't find robot name. If you have a Dash robot and you’ve given it a new name, use that name. Otherwise, just enter “Dash”"
    ]
    //Update assessment status
    var result:Bool = false
    if name==""{
        PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
    }
    else{
        DataStore.setStringData(Constants.ROBOT_CACHED_UUID, name)
        PlaygroundPage.current.assessmentStatus = .pass(message: "### Excellent! \n Now that Dash is connected, it’s time to code!\n\n[**Next Page**](@next)")
        result = true
    }
    return result
}
