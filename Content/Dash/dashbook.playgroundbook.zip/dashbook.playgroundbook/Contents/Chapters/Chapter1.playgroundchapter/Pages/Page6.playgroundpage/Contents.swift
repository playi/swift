/*:#localized(key: "FirstProseBlock")
 And...they’re off!
 
 **Goal:** program Dash to wait for the starting signal and then drive forward.
 
 Program Dash to display a **green light** and then race out of the gate (**move forward**) after hearing a clap using the `clapHeard()` function. Use an **if statement** to check whether the clap is heard.
 
 - example:\
 `  if(clapHeard() == true){`\
 `      playSound(SoundType.Hi)`\
 `  }`

 See all available [color](glossary://ColorType) commands.

 When you test your program, clap after you see the green light. You can add suspense by waiting a while before you clap!

 */
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, if)
//#-code-completion(identifier, show, ==, true, false, clapHeard(), moveForward(), setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
//#-end-hidden-code
playSound(SoundType.CarEngine)
setLight(ColorType.Red)
setLight(ColorType.Yellow)
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
exitProgram()
/*
 setLight(ColorType.Green)
 waitForClap()
 moveForward()
 */
//#-end-hidden-code
