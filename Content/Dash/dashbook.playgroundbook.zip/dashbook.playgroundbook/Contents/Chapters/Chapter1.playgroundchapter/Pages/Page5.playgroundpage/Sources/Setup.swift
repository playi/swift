import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


var delegate: UserProcessDelegate?
let commandSender:CommandSender = CommandSender()

public func setup(){
    let page = PlaygroundPage.current
    page.needsIndefiniteExecution = true
    let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
    delegate = UserProcessDelegate(pauseHandler: commandSender)
    delegate?.onAssessment = assessment
    proxy?.delegate = delegate
}

public func assessment(_ playgroundValue:PlaygroundValue)->Bool{
    // Assessment
    var correctSolution:[CommandType] = [
        CommandType.COMMAND_WAITFOR_BUTTON1,
        CommandType.COMMAND_TURN_LEFT,
        CommandType.COMMAND_SOUND_HI,
        CommandType.COMMAND_WAITFOR_BUTTON2,
        CommandType.COMMAND_TURN_RIGHT,
        CommandType.COMMAND_TURN_RIGHT,
        CommandType.COMMAND_SOUND_HI,
    ]
    var commands:[PlaygroundValue] = [PlaygroundValue]()
    if case let .array(values) = playgroundValue {
        commands = values
    }
    let result:Bool = RobotCommand.solutionChecker(commands, correctSolution)
    //Hints
    var failureHints = [
        NSLocalizedString("Enter one line of code for each text box. Make sure Dash turns to each competitor on a different **button press**.", comment: "")
    ]
//    var solutionHint = "waitForObstacleInFront()\nplaySoundCarEngine()"
//    solutionHint = "```swift\n\(solutionHint)\n```"
    //Update assessment status
    if(result){
        PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### Alright! \n Enough bantering! Let’s get going. \n\n[**Next Page**](@next)", comment: ""))
    }
    else{
        PlaygroundPage.current.assessmentStatus = .fail(hints: failureHints, solution: nil)
    }
    return result
}
