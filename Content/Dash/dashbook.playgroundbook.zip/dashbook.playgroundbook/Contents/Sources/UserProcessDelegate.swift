//
//  UserProcessDelegate.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/16/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import PlaygroundSupport

/*
 PlaygroundRemoteLiveViewProxyDelegate lives in the user processor.
 */
public class UserProcessDelegate: PlaygroundRemoteLiveViewProxyDelegate {
    
    public var pauseHandler: CommandPauseDelegate?
    
    public init(pauseHandler: CommandPauseDelegate?) {
        self.pauseHandler = pauseHandler
    }
    
    public var onAssessment:((PlaygroundValue)->Bool)?
    
    public init() {
        
    }
    
    //On live view connection closed
    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        // Kill user process if LiveView process closed.
        //PlaygroundPage.current.finishExecution()
    }
    
    //Receive message from live view
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        if case let .string(text) = message {
            if text.isEqual(Constants.COMMAND_FINISHED){
                // Indicate that the handler is ready for more commands.
                pauseHandler?.isReadyForMoreCommands = true
            }
        }
        if case let .dictionary(dict) = message {
            if case let .string(sensorValue) = dict[Constants.SENSOR_RECEIVED]! {
                let data:Bool = (sensorValue == "true")
                pauseHandler?.returnValue = data;
                pauseHandler?.isReadyForMoreCommands = true
            }
        }
        // Update Hints and Assessments
        if case .array(_) = message {
            let result:Bool = (onAssessment?(message))!
            //Send Result to live view
            let resultValue: PlaygroundValue = .boolean(result)
            remoteLiveViewProxy.send(resultValue)
        }
        // Kill user process if LiveView process closed.
        if case let .string(text) = message {
            if text.isEqual(Constants.PROGRAM_FINISHED){
                PlaygroundPage.current.finishExecution()
            }
        }
    }
}
