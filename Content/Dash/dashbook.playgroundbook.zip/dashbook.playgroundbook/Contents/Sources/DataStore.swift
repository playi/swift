//
//  DataStore.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/12/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import PlaygroundSupport

public class DataStore{
    
    public static func hasKey(_ key:String)->Bool{
        let dictionary = PlaygroundKeyValueStore.current
        return (dictionary[key] != nil)
    }
    
    public static func getStringData(_ key:String)->String?{
        var result:String?
        let dictionary = PlaygroundKeyValueStore.current
        if (dictionary[key] != nil) {
            let value = dictionary[key]!
            switch value{
            case let .string(s):
                result = s
            default:
                print("no string found in key:\(key)")
            }
        }
        return result
    }
    
    public static func setStringData(_ key:String, _ value:String)->(){
        let dictionary = PlaygroundKeyValueStore.current
        dictionary[key] = PlaygroundValue.string(value)
    }
    
}
