//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport

@objc(Book_Sources_LiveViewController)
public class LiveViewController: RobotViewController {
    /* We've already implemented the LiveViewController as RobotViewController, so just make a derived
       class to expose the functionality.  Assuming (maybe incorrectly?) that Swift Playgrounds is
       explicitly looking for a class called LiveViewController
    */
}
