//
//  RobotViewController.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/22/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import Foundation
import UIKit
import WebKit
import CoreBluetooth
import PlaygroundSupport
import PlaygroundBluetooth


public class RobotViewController: UIViewController {
    
    var bgImage:UIImageView!
    var fgImage:UIImageView!
    var robotView:RobotView!
    var log:UITextView!
    var commandText:UITextView!
    var programStateImage:UIImageView!
    var debugButton:UIButton!
    
    let robotCommand: RobotCommand = RobotCommand()
    var robotConnection:RobotConnection = RobotConnection()
    
    var page:Int = 1
    var isShowingResult = false
    var isLandscape:Bool = true
    
    var commandsForAssessment:[PlaygroundValue] = [PlaygroundValue]()
    
    var btView:PlaygroundBluetoothConnectionView!
    var btViewConstraints = [NSLayoutConstraint]()
    let btViewDelegate = ConnectionViewDelegate()
    
    public required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    public override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)

        let centralManager = PlaygroundBluetoothCentralManager(services: [transferServiceD1UUID, transferServiceD2UUID])
        centralManager.delegate = robotConnection
        robotConnection.centralManager = centralManager
    }
    
    public convenience init(_ page:Int = 1) {
        self.init(nibName: nil, bundle: nil)
        self.page = page
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup robot connection callbacks
        robotConnection.onCharacteristicsDiscovered = onRobotConnected
        robotConnection.onDataWritten = onCommandCompleted
        robotConnection.onPeripheralNotFound = onRobotNotFound
        robotConnection.onCharacteristicsUpdated0 = onSensorUpdated0
        robotConnection.onCharacteristicsUpdated1 = onSensorUpdated1
        robotConnection.onMyPrint = myPrint
        setupView()
    }
    
    public override func viewDidAppear(_ animated: Bool) { // Notifies the view controller that its view was added to a view hierarchy.
        super.viewDidAppear(animated)
        
    }
    
    public override func viewDidLayoutSubviews() { // Called to notify the view controller that its view has just laid out its subviews.
        super.viewDidLayoutSubviews()
        
    }
    
    public override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator){
        super.viewWillTransition(to: size, with: coordinator)
        myPrint("viewWillTransition:\(size)")
        if(size.width>size.height){
            setupPortraitView(size)
        }
        else{
            setupLandscapeView(size)
        }
    }
    
    func setupView(){
        myPrint("self.view.frame:\(self.view.frame)")
        isLandscape = (self.view.frame.width > self.view.frame.height)
        
        // Setup bg
        bgImage = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width/2, height: self.view.frame.height))
        bgImage.contentMode = UIView.ContentMode.scaleAspectFit
        bgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_bg.jpg")
        self.view.addSubview(bgImage)
        
        // Setup fg
        fgImage = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width/2, height: self.view.frame.height))
        fgImage.contentMode = UIView.ContentMode.scaleAspectFit
        fgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_fg.png")
        fgImage.isAccessibilityElement = true
        fgImage.accessibilityLabel = Constants.LIVEVIEW_DESCRIPTIONS[page-1]
        //fgImage.accessibilityHint = "Hint description, Dash needs to do bla bla bla"
        self.view.addSubview(fgImage)
        
        // Setup program state image
        programStateImage = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width/2, height: self.view.frame.height))
        programStateImage.contentMode = UIView.ContentMode.scaleAspectFit
        programStateImage.animationDuration = 1
        self.view.addSubview(programStateImage)
        
        // Setup commandText window
        commandText = UITextView(frame: CGRect(
            x: self.view.frame.width*5/100, y: self.view.frame.height*68/100,
            width: self.view.frame.width*89/200, height: self.view.frame.height*13/100))
        commandText.text = ""
        commandText.isEditable = false
        commandText.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 0)
        commandText.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        commandText.font = UIFont.init(name: "Avenir Next", size: 30)
        commandText.textAlignment = .center
        commandText.textContainer.lineBreakMode = .byWordWrapping
        self.view.addSubview(commandText)
        
        // Setup animation
        setCommandAnimation(CommandType.COMMAND_DISCONNECT.rawValue)
        
        // Setup Playground Bluetooth view
        btView = PlaygroundBluetoothConnectionView(centralManager: robotConnection.centralManager!)
        btView.delegate = btViewDelegate
        btView.dataSource = btViewDelegate;
        self.view.addSubview(btView)
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000)) {
            _ = self.robotConnection.centralManager!.connectToLastConnectedPeripheral()
        }
        
        // Setup debug log window & debug button
        log = UITextView(frame: CGRect(x: 0, y: 100, width: self.view.frame.width/2, height: 300))
        log.text = "My log:"
        log.isEditable = false
        log.backgroundColor = #colorLiteral(red: 0.1956433058, green: 0.2113749981, blue: 0.2356699705, alpha: 1)
        log.textColor = #colorLiteral(red: 1, green: 0.99997437, blue: 0.9999912977, alpha: 1)
        log.isHidden = true
        self.view.addSubview(log)
        debugButton = UIButton(frame: CGRect(x: 0, y: self.view.frame.height*0.95, width: 100, height: 50))
        debugButton.addTarget(self, action: #selector(onDebugButtonClicked(_:)), for: .touchUpInside)
        debugButton.setTitle("+", for: UIControl.State.normal)
        // self.view.addSubview(debugButton) // Disable the debug log
        
        if(isLandscape){
            setupLandscapeView(CGSize(width: self.view.frame.width/2, height: self.view.frame.height))
        }
        else{
            setupPortraitView(CGSize(width: self.view.frame.width, height: self.view.frame.height/2))
        }
    }
    
    func myPrint(_ input:String){
        // UIKit is not thread safe and should only be updated from the main thread
//        DispatchQueue.main.async {
//            self.log.text = self.log.text! + "\n\(input)"
//            let range:NSRange = NSMakeRange(self.log.text.characters.count - 1, 1);
//            self.log.scrollRangeToVisible(range)
//        }
    }
    
    func setupLandscapeView(_ size:CGSize){
        myPrint("setupLandscapeView():\(size)")
        isLandscape = true
        
        bgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_bg.jpg")
        bgImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        fgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_fg.png")
        fgImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        programStateImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        setCommandAnimationAsync(currentCommand)
        
        commandText.frame = CGRect(
            x: size.width*5/100, y: size.height*68/100,
            width: size.width*89/100, height: size.height*13/100)
        commandText.font = UIFont.init(name: "Avenir Next", size: 30)
        
        NSLayoutConstraint.deactivate(btViewConstraints)
        btViewConstraints.removeAll()
        btViewConstraints.append(btView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 20))
        btViewConstraints.append(btView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20))
        NSLayoutConstraint.activate(btViewConstraints)
        
        log.frame = CGRect(x: 0, y: 100, width: size.width, height: 300)
        debugButton.frame = CGRect(x: 0, y: size.height*0.95, width: 100, height: 50)
    }
    
    func setupPortraitView(_ size:CGSize){
        myPrint("setupPortraitView():\(size)")
        isLandscape = false
        
        bgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_bg_portrait.jpg")
        bgImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        fgImage.image = UIImage(imageLiteralResourceName:"Images/page\(page)_fg_portrait.png")
        fgImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        programStateImage.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        setCommandAnimationAsync(currentCommand)
        
        commandText.frame = CGRect(
            x: size.width*62/100, y: size.height*14/100,
            width: size.width*37/100, height: size.height*13/100)
        commandText.font = UIFont.init(name: "Avenir Next", size: 20)
        
        NSLayoutConstraint.deactivate(btViewConstraints)
        btViewConstraints.removeAll()
        btViewConstraints.append(btView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 75))
        btViewConstraints.append(btView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20))
        NSLayoutConstraint.activate(btViewConstraints)
        
        log.frame = CGRect(x: size.width/4, y: 100, width: size.width/2, height: 300)
        debugButton.frame = CGRect(x: 0, y: size.height*0.9, width: 100, height: 50)
    }
    
    @objc func onDebugButtonClicked(_ button: UIButton){
        log.isHidden = !log.isHidden
    }
    
    func onRobotConnected(peripheral: CBPeripheral){
        myPrint("onRobotConnected")
        self.sendMessage(.string(Constants.COMMAND_FINISHED))
        self.setCommandAnimationAsync(CommandType.COMMAND_IDLE)
    }
    
    func onRobotNotFound(){
        myPrint("onRobotNotFound")
        commandsForAssessment.removeAll()
        commandsForAssessment.append(PlaygroundValue.dictionary([CommandType.COMMAND_CONNECT_ROBOT.rawValue:.string("")]))
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500)) {
            self.sendMessage(.string(Constants.COMMAND_FINISHED))
        }
    }
    
    func onCommandCompleted(){
        myPrint("onCommandCompleted")
        self.sendMessage(.string(Constants.COMMAND_FINISHED))
    }
    
    var sensorType:String?
    var sensorValue:Bool = false
    var clapCount:UInt8 = 0;
    
    func resetSensorValues(){
        sensorType = nil
        sensorValue = false
        clapCount = 0
    }
    
    func onSensorUpdated0(_ data:Data){
        handleWaitForCommand0(data)
    }
    
    func onSensorUpdated1(_ data:Data){
        handleSensorCommand1(data)
        handleWaitForCommand1(data)
    }
    
    func handleWaitForCommand0(_ data:Data){
        guard let robotSensorType = robotCommand.sensorType else {
            return
        }
        switch(robotSensorType){
        case CommandType.COMMAND_WAITFOR_CLAP.rawValue:
            let micAmp:UInt8 = data.scanValue(start: 7, length: 1)
            let type2:UInt8 = data.scanValue(start: 15, length: 1)
            let data2:UInt8 = data.scanValue(start: 12, length: 1)
            let type1:UInt8 = data.scanValue(start: 19, length: 1)
            let data1:UInt8 = data.scanValue(start: 16, length: 1)
            if (type2 == 0x06) && (clapCount == 0) {
                clapCount = data2
            }
            if (type1 == 0x06) && (clapCount == 0) {
                clapCount = data1
            }
            myPrint("type2:\(type2) data2:\(data2) type1:\(type1) data1:\(data1) micAmp:\(micAmp)")
            var isTriggered:Bool = false
            isTriggered = (type2 == 0x06) && (clapCount != data2) && micAmp>0
            isTriggered = isTriggered || ((type1 == 0x06) && (clapCount != data1) && micAmp>0)
            if isTriggered{
                clapCount = 0
                robotCommand.sensorType = nil
                myPrint("onSensorUpdated: COMMAND_WAITFOR_CLAP")
                setCommandAnimationAsync(CommandType.FEEDBACK_WAITFOR_CLAP)
                DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000)) {
                    self.sendMessage(.string(Constants.COMMAND_FINISHED))
                }
            }
            break
        case CommandType.COMMAND_WAITFOR_BUTTON1.rawValue:
            let packet0:PacketSensor0 = data.withUnsafeBytes{$0.pointee}
            let highNibble:UInt8 = ((0xf0 & packet0.buttons_reserved)>>4)
            if (highNibble & Constants.SENSOR_BTN_1) != 0 {
                finishSensorCommand(CommandType.COMMAND_WAITFOR_BUTTON1.rawValue)
            }
            break
        case CommandType.COMMAND_WAITFOR_BUTTON2.rawValue:
            let packet0:PacketSensor0 = data.withUnsafeBytes{$0.pointee}
            let highNibble:UInt8 = ((0xf0 & packet0.buttons_reserved)>>4)
            if (highNibble & Constants.SENSOR_BTN_2) != 0 {
                finishSensorCommand(CommandType.COMMAND_WAITFOR_BUTTON2.rawValue)
            }
            break
        case CommandType.COMMAND_WAITFOR_BUTTON3.rawValue:
            let packet0:PacketSensor0 = data.withUnsafeBytes{$0.pointee}
            let highNibble:UInt8 = ((0xf0 & packet0.buttons_reserved)>>4)
            if (highNibble & Constants.SENSOR_BTN_3) != 0 {
                finishSensorCommand(CommandType.COMMAND_WAITFOR_BUTTON3.rawValue)
            }
            break
        default:
            break
        }
    }
    
    func handleWaitForCommand1(_ data:Data){
        guard let robotSensorType = robotCommand.sensorType else {
            return
        }
        switch(robotSensorType){
        case CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue:
            let packet:PacketSensor1 = data.withUnsafeBytes{$0.pointee}
            if packet.distLeft > 80 && packet.distRight > 80{
                finishSensorCommand(CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue)
            }
            break
        case CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue:
            let packet:PacketSensor1 = data.withUnsafeBytes{$0.pointee}
            if packet.distRear > 80{
                finishSensorCommand(CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue)
            }
            break
        default:
            break
        }
    }
    
    func handleSensorCommand1(_ data:Data){
        if(sensorType != nil){
            switch(sensorType!){
            case CommandType.COMMAND_GET_SENSOR_FRONT.rawValue:
                setCommandAnimationAsync(CommandType.COMMAND_GET_SENSOR_FRONT)
                let packet:PacketSensor1 = data.withUnsafeBytes{$0.pointee}
                sensorValue = (packet.distLeft > 80 && packet.distRight > 80) || sensorValue;
                break
            case CommandType.COMMAND_GET_SENSOR_REAR.rawValue:
                setCommandAnimationAsync(CommandType.COMMAND_GET_SENSOR_REAR)
                let packet:PacketSensor1 = data.withUnsafeBytes{$0.pointee}
                sensorValue = (packet.distRear > 80) || sensorValue;
                break
            default:
                break
            }
        }
    }
    
    func finishSensorCommand(_ sensor:String){
        var sensorName:String = sensor
        robotCommand.sensorType = nil
        myPrint("onSensorUpdated: \(sensorName)")
        sensorName = sensorName.replacingOccurrences(of:"command", with:"feedback")
        self.setCommandAnimationAsync(sensorName)
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000)) {
            self.sendMessage(.string(Constants.COMMAND_FINISHED))
        }
    }
    
    func addCommandToAssessmentArray(_ command:PlaygroundValue){
        if(self.commandsForAssessment.count <= 30){
            self.commandsForAssessment.append(command)
        }
    }
    
    func processCommand(_ command:PlaygroundValue){
        robotCommand.sendRobotCommand(robotConnection, command)
    }
    
    func processSensorCommand(_ command:PlaygroundValue){
        if case let .string(sensorData) = command {
            self.resetSensorValues()
            sensorType = sensorData;
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(100)) {
                self.sensorType = nil
                let message:PlaygroundValue = .dictionary([Constants.SENSOR_RECEIVED:.string("\(self.sensorValue)")])
                self.sendMessage(message)
            }
        }
    }
    
    func processWaitCommand(_ command:PlaygroundValue){
        robotCommand.sendRobotCommand(robotConnection, command)
    }
    
    func setCommandAnimationAsync(_ command:PlaygroundValue){
        if case let .string(text) = command {
            setCommandAnimationAsync(text)
        }
    }
    
    func setCommandAnimationAsync(_ command:CommandType){
        setCommandAnimationAsync(command.rawValue)
    }
    
    var currentCommand:String = "";
    
    func setCommandAnimationAsync(_ text:String){
        DispatchQueue.main.async {
            self.setCommandAnimation(text)
        }
    }
    
    func setCommandAnimation(_ text:String){
        currentCommand = text
        switch(currentCommand){
        //Animations
        case CommandType.COMMAND_WAITFOR_CLAP.rawValue:
            programStateImage.animationImages = (isLandscape) ? Constants.COMMAND_WAITFOR_CLAP : Constants.COMMAND_WAITFOR_CLAP_PORTRAIT
            break
        case CommandType.COMMAND_IDLE.rawValue:
            programStateImage.animationImages = (isLandscape) ? Constants.COMMAND_IDLE : Constants.COMMAND_IDLE_PORTRAIT
            break
        case CommandType.COMMAND_DISCONNECT.rawValue:
            programStateImage.animationImages = (isLandscape) ? Constants.COMMAND_DISCONNECT : Constants.COMMAND_DISCONNECT_PORTRAIT
            break
        case CommandType.FEEDBACK_WAITFOR_CLAP.rawValue:
            programStateImage.animationImages = (isLandscape) ? Constants.FEEDBACK_WAITFOR_CLAP : Constants.FEEDBACK_WAITFOR_CLAP_PORTRAIT
            break
        //Single image
        case CommandType.COMMAND_WAITFOR_BUTTON1.rawValue,
             CommandType.COMMAND_WAITFOR_BUTTON2.rawValue,
             CommandType.COMMAND_WAITFOR_BUTTON3.rawValue,
             
             CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue,
             CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue,
             CommandType.COMMAND_GET_SENSOR_FRONT.rawValue,
             CommandType.COMMAND_GET_SENSOR_REAR.rawValue,
             
             CommandType.COMMAND_LIGHT_GREEN.rawValue,
             CommandType.COMMAND_LIGHT_YELLOW.rawValue,
             CommandType.COMMAND_LIGHT_RED.rawValue,
             CommandType.COMMAND_LIGHT_WHITE.rawValue,
             CommandType.COMMAND_LIGHT_BLUE.rawValue,
             
             CommandType.COMMAND_MOVE_FORWARD.rawValue,
             CommandType.COMMAND_MOVE_BACKWARD.rawValue,
             CommandType.COMMAND_TURN_RIGHT.rawValue,
             CommandType.COMMAND_TURN_LEFT.rawValue,
             
             CommandType.COMMAND_SOUND_ENGINE.rawValue,
             CommandType.COMMAND_SOUND_HI.rawValue,
             CommandType.COMMAND_SOUND_AWESOME.rawValue,
             CommandType.COMMAND_SOUND_FANTASTIC.rawValue,
             CommandType.COMMAND_SOUND_OHNO.rawValue,
             CommandType.COMMAND_SOUND_WHA.rawValue,
             
             CommandType.COMMAND_SOUND_BRAGGING.rawValue,
             CommandType.COMMAND_SOUND_HEREICOME.rawValue,
             CommandType.COMMAND_SOUND_INTERESTING.rawValue,
             CommandType.COMMAND_SOUND_INPUTSOUTPUTS.rawValue,
             CommandType.COMMAND_SOUND_HORN.rawValue,
             
             CommandType.FEEDBACK_WAITFOR_OBSTACLE_FRONT.rawValue,
             CommandType.FEEDBACK_WAITFOR_OBSTACLE_REAR.rawValue,
             CommandType.FEEDBACK_WAITFOR_BUTTON1.rawValue,
             CommandType.FEEDBACK_WAITFOR_BUTTON2.rawValue,
             CommandType.FEEDBACK_WAITFOR_BUTTON3.rawValue,
             CommandType.FEEDBACK_FAIL.rawValue,
             CommandType.FEEDBACK_SUCCESS.rawValue:
            
            let name:String = (isLandscape) ? currentCommand : currentCommand+"_portrait"
            programStateImage.animationImages = [UIImage(imageLiteralResourceName: name)]
            break
        default:
            currentCommand = ""
            break
        }
        programStateImage.startAnimating()
        commandText.text = Constants.commandTextToLocalizedText(currentCommand)
        UIAccessibility.post(notification: UIAccessibility.Notification.announcement,
                             argument: String(format: Constants.commandTypeToAccessibilityText(currentCommand)))
    }
    
    func exitProgram(){
        // All commands executed
        myPrint("All commands executed")
        let message: PlaygroundValue = .array(commandsForAssessment)
        sendMessage(message)
        commandsForAssessment.removeAll()
    }
}

class ConnectionViewDelegate: PlaygroundBluetoothConnectionViewDelegate, PlaygroundBluetoothConnectionViewDataSource {
    
    // MARK: PlaygroundBluetoothConnectionViewDataSource
    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, itemForPeripheral peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?) -> PlaygroundBluetoothConnectionView.Item {
        // Provide display information associated with a peripheral item.
        let name = peripheral.name ?? NSLocalizedString("Unknown Device", comment: "")
        let icon = #imageLiteral(resourceName: "robotAvatar.png")
        let issueIcon = icon
        return PlaygroundBluetoothConnectionView.Item(name: name, icon: icon, issueIcon: issueIcon, firmwareStatus: nil, batteryLevel: nil)
    }
    
    // MARK: PlaygroundBluetoothConnectionView Delegate
    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, shouldDisplayDiscovered peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?, rssi: Double) -> Bool {
        // Filter out peripheral items (optional)
        return true
    }
    
    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, titleFor state: PlaygroundBluetoothConnectionView.State) -> String {
        // Provide a localized title for the given state of the connection view.
        switch state {
        case .noConnection:
            return NSLocalizedString("Connect Dash", comment: "")
        case .connecting:
            return NSLocalizedString("Connecting Dash", comment: "")
        case .searchingForPeripherals:
            return NSLocalizedString("Searching for Dash", comment: "")
        case .selectingPeripherals:
            return NSLocalizedString("Select Dash", comment: "")
        case .connectedPeripheralFirmwareOutOfDate:
            return NSLocalizedString("Connect to a Different Dash", comment: "")
        }
    }
    
    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, firmwareUpdateInstructionsFor peripheral: CBPeripheral) -> String {
        // Provide firmware update instructions.
        return "Firmware update instructions here."
    }
}

extension RobotViewController: PlaygroundLiveViewMessageHandler {
    
    public func liveViewMessageConnectionOpened() {
        self.log.text = ""
        isShowingResult = false
        myPrint("liveViewMessageConnectionOpened")
    }
    
    public func liveViewMessageConnectionClosed() {
        myPrint("liveViewMessageConnectionClosed")
        commandsForAssessment.removeAll()
        robotCommand.sensorType = nil
        if(!isShowingResult)
        {
            if robotConnection.isConnected {
                setCommandAnimationAsync(CommandType.COMMAND_IDLE)
            }
            else{
                setCommandAnimationAsync(CommandType.COMMAND_DISCONNECT)
            }
        }
    }
    
    public func receive(_ message: PlaygroundValue) { // Receive message from Constants.swift // TODO:refactor this to seperate the special case for page 1
        myPrint("Receive message from Constants.swift")
        if case let .string(command) = message { // Commands
            if command.isEqual(CommandType.COMMAND_EXIT_PROGRAM.rawValue){
                exitProgram()
            }
            if robotConnection.isConnected {
                setCommandAnimationAsync(message)
                addCommandToAssessmentArray(message)
                if robotCommand.isSensorCommand(message){
                    processSensorCommand(message)
                }
                else if robotCommand.isWaitCommand(message){
                    processWaitCommand(message)
                }
                else{
                  processCommand(message)
                }
            }
            else{ // Connection not ready
                sendMessage(.string(Constants.PROGRAM_FINISHED))
                setCommandAnimationAsync(CommandType.COMMAND_DISCONNECT)
            }
        }
        else if case .dictionary(_) = message { // Connect to robot
            processCommand(message)
            addCommandToAssessmentArray(message)
        }
        else if case let .boolean(result) = message { // Program Results
            programStateImage.stopAnimating()
            isShowingResult = true
            if result{
                myPrint("Receive result from Constants.swift: feedback_success")
                setCommandAnimationAsync(CommandType.FEEDBACK_SUCCESS)
                if robotConnection.isConnected {
                    robotCommand.sendRobotCommand(robotConnection, PlaygroundValue.string(CommandType.COMMAND_SOUND_AWESOME.rawValue))
                }
            }
            else{
                myPrint("Receive result from Constants.swift: feedback_fail")
                setCommandAnimationAsync(CommandType.FEEDBACK_FAIL)
                if robotConnection.isConnected {
                    robotCommand.sendRobotCommand(robotConnection, PlaygroundValue.string(CommandType.COMMAND_SOUND_WHA.rawValue))
                }
            }
            sendMessage(.string(Constants.PROGRAM_FINISHED))
        }
    }
    
    public func sendMessage(_ message: PlaygroundValue) { // Send message to Constants.swift
        myPrint("Send message to Constants.swift\(message)")
        send(message)
    }
}
