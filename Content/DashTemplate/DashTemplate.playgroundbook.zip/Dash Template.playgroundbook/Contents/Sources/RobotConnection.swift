//
//  RobotConnection.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/10/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import PlaygroundBluetooth
import PlaygroundSupport
import Foundation
import CoreBluetooth

// Obscure unused packpage data in dashbook
struct PacketSensor0{
    var dataA0:UInt16
    var dataA1:UInt16
    var dataA2:UInt16
    var dataA3:UInt8
    var micAmp:UInt8
    var buttons_reserved:UInt8
    var dataB2:UInt16
    var flags:UInt8
    
    //    var data0_1:UInt8
    //    var data0_2:UInt8
    //    var data0_3:UInt8
    //    var data0_4:UInt8
    //    var data0_5:UInt8
    //    var data0_6:UInt8
    //    var data0_7:UInt8
    //    var type0:UInt8
    
    var data2_1:UInt8//12
    var data2_2:UInt8//13
    var data2_3:UInt8//14
    var type2:UInt8//15
    
    var data1_1:UInt8//16
    var data1_2:UInt8//17
    var data1_3:UInt8//18
    var type1:UInt8//19
}

struct PacketSensor1{
    var dataH1:UInt16
    var dataG1:UInt16
    var dataG2:UInt16
    var distLeft:UInt8
    var distRight:UInt8
    var distRear:UInt8
    var dataP1:UInt8
    var dataP2:UInt16
    var dataP3:UInt16
    var dataC1:UInt16
    var dataC2:UInt16
    var dataH2:UInt16
}

extension Data {
    func scanValue<T>(start: Int, length: Int) -> T {
        return self.subdata(in: start..<start+length).withUnsafeBytes { $0.pointee }
    }
}

public class RobotConnection: NSObject, PlaygroundBluetoothCentralManagerDelegate, CBPeripheralDelegate {
    
    public var onPeripheralDiscovered:(([CBPeripheral])->Void)?     // Found robot
    public var onPeripheralNotFound:(()->Void)?                     // Can't connect to robot
    public var onCharacteristicsDiscovered:((CBPeripheral)->Void)?  // Robot connected
    public var onDataWritten:(()->Void)?                            // Command sent
    public var onCharacteristicsUpdated0:((Data)->Void)?             // Sensor callback
    public var onCharacteristicsUpdated1:((Data)->Void)?             // Sensor callback
    public var onMyPrint:((String)->Void)?                          // Debug print
    
    public var isConnected:Bool = false
    
    public var centralManager: PlaygroundBluetoothCentralManager?
    private var discoveredPeripheral: CBPeripheral?
    private var discoveredPeripherals = [CBPeripheral]()
    private var commandCharacteristic: CBCharacteristic?
    private var sensorPack2Characteristic: CBCharacteristic?
    private let data = NSMutableData()
    private let isDebugPrint:Bool = false
    
    public override init(){
        super.init()
    }
    
    public func centralManagerStateDidChange(_ centralManager: PlaygroundBluetoothCentralManager) {
        // Handle Bluetooth state changes.
        guard centralManager.state  == .poweredOn else {
            switch (centralManager.state) {
            case .poweredOn: myPrint("Bluetooth: Powered on")
            case .poweredOff: myPrint("Bluetooth: Powered off")
            case .unauthorized: myPrint("Bluetooth: Unauthorized")
            case .unknown: myPrint("Bluetooth: Unknown")
            case .resetting: myPrint("Bluetooth: Resetting")
            case .unsupported: myPrint("Bluetooth: Unsupported")
            }
            return
        }
    }
    
    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDiscover peripheral: CBPeripheral, withAdvertisementData advertisementData: [String : Any]?, rssi: Double)  {
        // Handle peripheral discovery.
        myPrint("Discovered \(peripheral.name ?? "unnamed peripheral") at \(rssi)")
    }
    
    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, willConnectTo peripheral: CBPeripheral) {
        // Handle peripheral connection attempts (prior to connection being made).
    }
    
    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didConnectTo peripheral: CBPeripheral) {
        // Handle successful peripheral connection.
        myPrint("Peripheral \(peripheral.name ?? "unnamed peripheral") connected")
        peripheral.delegate = self                          // Make sure we get the discovery callbacks
        peripheral.discoverServices([transferServiceD1UUID, transferServiceD2UUID])  // Search only for services that match our service UUID
        discoveredPeripheral = peripheral
    }
    
    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didFailToConnectTo peripheral: CBPeripheral, error: Error?) {
        // Handle failed peripheral connection.
    }
    
    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDisconnectFrom peripheral: CBPeripheral, error: Error?) {
        // Handle peripheral disconnection.
        discoveredPeripheral = nil
    }

    func myPrint(_ input:String){
        if isDebugPrint{
            onMyPrint?(input)
        }
        else{
            print(input)
        }
    }
    
    public func sendRobotData(_ data:Data, _ duration:Int){
        discoveredPeripheral!.writeValue(data, for: commandCharacteristic!, type: CBCharacteristicWriteType.withoutResponse)
        myPrint("Command Sent: \(data)")
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(duration) ) {
            self.onDataWritten?()
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil else {
            myPrint("Error discovering services: \(error!.localizedDescription)")
            cleanup()
            return
        }
        guard let services = peripheral.services else {
            return
        }
        for service in services { // Find the characteristic we want in services
            myPrint("service: \(service)")
            peripheral.discoverCharacteristics([transferCharacteristicCommandControlUUID, transferCharacteristicSensorPacket1UUID, transferCharacteristicSensorPacket2UUID], for: service)
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else {
            myPrint("Error discovering services: \(error!.localizedDescription)")
            cleanup()
            return
        }
        guard let characteristics = service.characteristics else {
            return
        }
        for characteristic in characteristics {
            if characteristic.uuid.isEqual(transferCharacteristicCommandControlUUID) {
                commandCharacteristic = characteristic
                isConnected = true
                onCharacteristicsDiscovered?(peripheral)
            }
            if characteristic.uuid.isEqual(transferCharacteristicSensorPacket2UUID) ||
                characteristic.uuid.isEqual(transferCharacteristicSensorPacket1UUID) {
                peripheral.setNotifyValue(true, for: characteristic) // Subscribe to it
            }
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?){
        guard error == nil else {
            myPrint("Error writing data: \(error!.localizedDescription)")
            return
        }
        onDataWritten?()
    }
    
    // Callback on data arrival via notification on the characteristic
    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            myPrint("Error discovering services: \(error!.localizedDescription)")
            return
        }
        if characteristic.uuid.isEqual(transferCharacteristicSensorPacket1UUID) {
            onCharacteristicsUpdated0?(characteristic.value!)
        }
        else if characteristic.uuid.isEqual(transferCharacteristicSensorPacket2UUID) {
            onCharacteristicsUpdated1?(characteristic.value!)
        }
    }
    
    // The peripheral checks whether our subscribe/unsubscribe happened or not
    public func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            myPrint("Error changing notification state: \(error!.localizedDescription)")
            return
        }
        if (characteristic.isNotifying) {
            myPrint("Notification began on \(characteristic)")
        } else {
            myPrint("Notification stopped on (\(characteristic))  Disconnecting")
//            centralManager?.cancelPeripheralConnection(peripheral)
        }
    }
    
    // Clean up when things either go wrong, or done with the connection, it cancels any subscriptions if there are any. func didUpdateNotificationStateFor will cancel the connection if a subscription is involved
    private func cleanup() {
        guard discoveredPeripheral?.state == .connected else {
            return
        }
        guard let services = discoveredPeripheral?.services else {
//            cancelPeripheralConnection()
            return
        }
        for service in services {
            guard let characteristics = service.characteristics else {
                continue
            }
            for characteristic in characteristics {
                if characteristic.uuid.isEqual(transferCharacteristicCommandControlUUID) && characteristic.isNotifying {
                    discoveredPeripheral?.setNotifyValue(false, for: characteristic)
                    return
                }
            }
        }
    }
    
}
