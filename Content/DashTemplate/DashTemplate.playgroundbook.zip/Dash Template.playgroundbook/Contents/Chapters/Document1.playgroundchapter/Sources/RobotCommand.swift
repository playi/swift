//
//  RobotCommand.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/10/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import Foundation
import PlaygroundSupport


public class RobotCommand: NSObject{
    
    public var onVirtualDataWritten:(()->Void)?     // When user doesn't have a physical robot
    public var onVirtualRobotConnected:(()->Void)?
    public var onVirtualSensorUpdated:(()->Void)?
    public var useVirtualRobot:Bool = false         // TODO:should be getter
    public var sensorType:String?
    
    // To view bytes data, build and run Wonder and view in xcode console
    let LIGHT_BLUE : [UInt32]       = [ 0xff000003, 0xff00000b, 0xff00000c]
    let LIGHT_GREEN : [UInt32]      = [ 0x0bff2103, 0x0bff210b, 0x0bff210c]
    let LIGHT_YELLOW : [UInt32]     = [ 0x0032ff03, 0x0032ff0b, 0x0032ff0c]
    let LIGHT_RED : [UInt32]        = [ 0x0000ff03, 0x0000ff0b, 0x0000ff0c]
    let LIGHT_WHITE : [UInt32]      = [ 0x78abb403, 0x78abb40b, 0x78abb40c]
    
    let MOVE_FORWARD : [UInt32]     = [ 0x00009623, 0x0000e803, 0x00000092]
    let MOVE_BACKWARD : [UInt32]    = [ 0x00006a23, 0x003fe803, 0x00000092]
    let TURN_RIGHT : [UInt32]       = [ 0x63000023, 0xc0c0e803, 0x00000092]
    let TURN_LEFT : [UInt32]        = [ 0x9d000023, 0x0000e803, 0x00000092]
    
    let SOUND_ENGINE : [UInt32]     = [ 0x53595318, 0x474e4554, 0x5f454e49, 0x00564552]
    let SOUND_HI : [UInt32]         = [ 0x53595318, 0x53414454, 0x49485f48, 0x004f565f]
    let SOUND_AWESOME : [UInt32]    = [ 0x53595318, 0x45574154, 0x454d4f53, 0x00000000]
    let SOUND_FANTASTIC : [UInt32]  = [ 0x53595318, 0x4e414654, 0x54534154, 0x00004349]
    let SOUND_OHNO : [UInt32]       = [ 0x53595318, 0x5f484f54, 0x555f4f4e, 0x0000484e]
    let SOUND_WHA : [UInt32]        = [ 0x53595318, 0x41485754, 0x524f4853, 0x00000054]
    
    //<18 53 59 53      54 42 52 41         47 47 49 4e         47 31 41>
    let SOUND_BRAGGING : [UInt32]       = [ 0x53595318, 0x41524254, 0x4e494747, 0x00413147]
    //<18 53 59 53      54 48 45 52         45 49 43 4f         4d 45 00>
    let SOUND_HEREICOME : [UInt32]      = [ 0x53595318, 0x52454854, 0x4f434945, 0x0000454d]
    //<18 53 59 53      54 49 4e 54         52 45 53 54         49 4e 47>
    let SOUND_INTERESTING : [UInt32]    = [ 0x53595318, 0x544e4954, 0x54534552, 0x00474e49]
    //<18 53 59 53      54 49 4e 50         55 54 53 00         00 00 00>
    let SOUND_INPUTSOUTPUTS : [UInt32]  = [ 0x53595318, 0x504e4954, 0x00535455, 0x00000000]
    //<18 53 59 53      54 48 41 50         50 59 5f 48         4f 4e 4b>
    let SOUND_HORN : [UInt32]           = [ 0x53595318, 0x50414854, 0x485f5950, 0x004b4e4f]
    
    public func connectVirtualRobot(){
        useVirtualRobot = true
        onVirtualRobotConnected?()
    }
    
    public func isSensorCommand(_ command:PlaygroundValue)->Bool{
        switch command {
        case let .string(text):
            switch(text){
                case CommandType.COMMAND_GET_SENSOR_FRONT.rawValue,
                     CommandType.COMMAND_GET_SENSOR_REAR.rawValue:
                return true
            default:
                return false
            }
        default:
            return false
        }
    }
    
    public func isWaitCommand(_ command:PlaygroundValue)->Bool{
        switch command {
        case let .string(text):
            switch(text){
                case CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue,
                     CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue,
                     CommandType.COMMAND_WAITFOR_CLAP.rawValue,
                     CommandType.COMMAND_WAITFOR_BUTTON1.rawValue,
                     CommandType.COMMAND_WAITFOR_BUTTON2.rawValue,
                     CommandType.COMMAND_WAITFOR_BUTTON3.rawValue:
                return true
            default:
                return false
            }
        default:
            return false
        }
    }
    
    public func sendRobotCommand(_ robotConnection:RobotConnection, _ command:PlaygroundValue){ // Send command to robot
        // TODO: refact this function to processRobotCommand since it has sensor command too. command should also to be refactored to dict(commandType:String, command:String)
        switch command {
        case let .string(text):
            var fourBytes : [UInt32] = []
            var duration:Int = 2000
            sensorType = nil // Reset sensor type
            switch(text){
            case CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue,
                 CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue,
                 CommandType.COMMAND_WAITFOR_CLAP.rawValue,
                 CommandType.COMMAND_WAITFOR_BUTTON1.rawValue,
                 CommandType.COMMAND_WAITFOR_BUTTON2.rawValue,
                 CommandType.COMMAND_WAITFOR_BUTTON3.rawValue:
                sensorType = text
                break
            case CommandType.COMMAND_LIGHT_GREEN.rawValue:
                fourBytes = LIGHT_GREEN
                duration = 500
                break
            case CommandType.COMMAND_LIGHT_YELLOW.rawValue:
                fourBytes = LIGHT_YELLOW
                duration = 500
                break
            case CommandType.COMMAND_LIGHT_RED.rawValue:
                fourBytes = LIGHT_RED
                duration = 500
                break
            case CommandType.COMMAND_LIGHT_WHITE.rawValue:
                fourBytes = LIGHT_WHITE
                duration = 500
                break
            case CommandType.COMMAND_LIGHT_BLUE.rawValue:
                fourBytes = LIGHT_BLUE
                duration = 500
                break
            case CommandType.COMMAND_MOVE_FORWARD.rawValue:
                fourBytes = MOVE_FORWARD
                break
            case CommandType.COMMAND_MOVE_BACKWARD.rawValue:
                fourBytes = MOVE_BACKWARD
                break
            case CommandType.COMMAND_TURN_RIGHT.rawValue:
                fourBytes = TURN_RIGHT
                break
            case CommandType.COMMAND_TURN_LEFT.rawValue:
                fourBytes = TURN_LEFT
                break
            case CommandType.COMMAND_SOUND_ENGINE.rawValue:
                fourBytes = SOUND_ENGINE
                break
            case CommandType.COMMAND_SOUND_HI.rawValue:
                fourBytes = SOUND_HI
                break
            case CommandType.COMMAND_SOUND_AWESOME.rawValue:
                fourBytes = SOUND_AWESOME
                break
            case CommandType.COMMAND_SOUND_FANTASTIC.rawValue:
                fourBytes = SOUND_FANTASTIC
                break
            case CommandType.COMMAND_SOUND_OHNO.rawValue:
                fourBytes = SOUND_OHNO
                break
            case CommandType.COMMAND_SOUND_WHA.rawValue:
                fourBytes = SOUND_WHA
                break
            case CommandType.COMMAND_SOUND_BRAGGING.rawValue:
                fourBytes = SOUND_BRAGGING
                duration = 5000
                break
            case CommandType.COMMAND_SOUND_HEREICOME.rawValue:
                fourBytes = SOUND_HEREICOME
                break
            case CommandType.COMMAND_SOUND_INTERESTING.rawValue:
                fourBytes = SOUND_INTERESTING
                duration = 4000
                break
            case CommandType.COMMAND_SOUND_INPUTSOUTPUTS.rawValue:
                fourBytes = SOUND_INPUTSOUTPUTS
                duration = 5000
                break
            case CommandType.COMMAND_SOUND_HORN.rawValue:
                fourBytes = SOUND_HORN
                break
            default:
                break
            }
            if sensorType==nil {
                if(!useVirtualRobot){
                    let data:Data = NSData(bytes: fourBytes, length: fourBytes.count*4) as Data
                    robotConnection.sendRobotData(data, duration)
                }
                else{
                    onVirtualDataWritten?()
                }
            }
            else{
                if(useVirtualRobot){
                    onVirtualSensorUpdated?()
                }
            }
            break
        default:
            break
        }
    }
    
    public static func solutionChecker(_ commands:[PlaygroundValue], _ correctSolution:[CommandType])->Bool{ // Don't pass in robot connect command into this
        var result:Bool = false
        if commands.count == correctSolution.count{
            for index in 0...(commands.count-1) {
                let command:PlaygroundValue = commands[index]
                if case let .string(text) = command {
                    if !text.isEqual(correctSolution[index].rawValue){
                        break
                    }
                }
                if index==(commands.count-1){
                    result = true
                }
            }
        }
        return result
    }
}
