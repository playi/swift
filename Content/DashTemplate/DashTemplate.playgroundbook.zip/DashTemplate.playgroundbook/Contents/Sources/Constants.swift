//
//  Constants.swift
//  DashBook
//
//  Created by Wonder Workshop on 8/9/16.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth
import PlaygroundSupport

let TRANSFER_SERVICE_D1_UUID                        = "AF237777-879D-6186-1F49-DECA0E85D9C1"
let TRANSFER_SERVICE_D2_UUID                        = "AF237778-879D-6186-1F49-DECA0E85D9C1"
let TRNASFER_CHARACTERISTIC_COMMAND_CONTROL_UUID    = "AF230002-879D-6186-1F49-DECA0E85D9C1"
let TRNASFER_CHARACTERISTIC_SENSOR_PACKET1_UUID     = "AF230003-879D-6186-1F49-DECA0E85D9C1"
let TRNASFER_CHARACTERISTIC_SENSOR_PACKET2_UUID     = "AF230006-879D-6186-1F49-DECA0E85D9C1"

let transferServiceD1UUID = CBUUID(string: TRANSFER_SERVICE_D1_UUID)
let transferServiceD2UUID = CBUUID(string: TRANSFER_SERVICE_D2_UUID)
let transferCharacteristicCommandControlUUID = CBUUID(string: TRNASFER_CHARACTERISTIC_COMMAND_CONTROL_UUID)
let transferCharacteristicSensorPacket1UUID = CBUUID(string: TRNASFER_CHARACTERISTIC_SENSOR_PACKET1_UUID)
let transferCharacteristicSensorPacket2UUID = CBUUID(string: TRNASFER_CHARACTERISTIC_SENSOR_PACKET2_UUID)

public class Constants:NSObject{
    
    public static let ROBOT_CACHED_UUID = "RobotCachedUUID"
    public static let PROGRAM_FINISHED = "ProgramFinished"
    public static let COMMAND_FINISHED = "CommandFinished"
    public static let SENSOR_RECEIVED = "SensorReceived"
    
    public static let PROTECTED_NAME1 = "Virtual Dash"
    public static let PROTECTED_NAME2 = "VirtualDash"
    
    public static let SENSOR_FLAGS_CLAP:UInt8   = 0x01
    public static let SENSOR_BTN_MAIN:UInt8     = (1 << 0)
    public static let SENSOR_BTN_1:UInt8        = (1 << 1)
    public static let SENSOR_BTN_2:UInt8        = (1 << 2)
    public static let SENSOR_BTN_3:UInt8        = (1 << 3)
    
    public static func commandTextToLocalizedText(_ text:String)->String{
        if(text == ""){
            return ""
        }
        let type:CommandType = CommandType(rawValue: text)!
        return self.commandTypeToLocalizedText(type)
    }
    
    public static func commandTypeToLocalizedText(_ type:CommandType)->String{
        var text:String = ""
        switch(type) {
            
        case .COMMAND_MOVE_FORWARD:
            text = NSLocalizedString("I'm moving forward!", comment: "")
        case .COMMAND_MOVE_BACKWARD:
            text = NSLocalizedString("Backing up!", comment: "")
        case .COMMAND_TURN_RIGHT:
            text = NSLocalizedString("And a quick turn to the right!", comment: "")
        case .COMMAND_TURN_LEFT:
            text = NSLocalizedString("And a quick turn to the left!", comment: "")
            
        case .COMMAND_LIGHT_GREEN:
            text = NSLocalizedString("Green lights on!", comment: "")
        case .COMMAND_LIGHT_YELLOW:
            text = NSLocalizedString("Yellow lights on!", comment: "")
        case .COMMAND_LIGHT_RED:
            text = NSLocalizedString("Red lights on!", comment: "")
        case .COMMAND_LIGHT_WHITE:
            text = NSLocalizedString("White lights on!", comment: "")
        case .COMMAND_LIGHT_BLUE:
            text = NSLocalizedString("Blue lights on!", comment: "")
            
        case .COMMAND_SOUND_ENGINE:
            text = NSLocalizedString("Revving the engine!", comment: "")
        case .COMMAND_SOUND_HI:
            text = NSLocalizedString("Saying \"Hi!\"", comment: "")
        case .COMMAND_SOUND_AWESOME:
            text = NSLocalizedString("Saying \"Awesome!\"", comment: "")
        case .COMMAND_SOUND_FANTASTIC:
            text = NSLocalizedString("Saying \"Fantastic!\"", comment: "")
        case .COMMAND_SOUND_OHNO:
            text = NSLocalizedString("Saying \"Oh no!\"", comment: "")
        case .COMMAND_SOUND_WHA:
            text = NSLocalizedString("Saying \"Wha!\"", comment: "")
        case .COMMAND_SOUND_BRAGGING:
            text = NSLocalizedString("Bragging!", comment: "")
        case .COMMAND_SOUND_HEREICOME:
            text = NSLocalizedString("Saying \"Here I come!\"", comment: "")
        case .COMMAND_SOUND_INTERESTING:
            text = NSLocalizedString("Saying \"Interesting!\"", comment: "")
        case .COMMAND_SOUND_INPUTSOUTPUTS:
            text = NSLocalizedString("Singing \"Inputs & Outputs!\"", comment: "")
        case .COMMAND_SOUND_HORN:
            text = NSLocalizedString("Honking the horn!", comment: "")
            
        case .COMMAND_WAITFOR_OBSTACLE_FRONT:
            text = NSLocalizedString("Not seeing anything in front of me yet...", comment: "")
        case .COMMAND_WAITFOR_OBSTACLE_REAR:
            text = NSLocalizedString("Not seeing anything behind me yet...", comment: "")
        case .COMMAND_WAITFOR_CLAP:
            text = NSLocalizedString("Listening for a clap...", comment: "")
        case .COMMAND_WAITFOR_BUTTON1:
            text = NSLocalizedString("Waiting for Button 1 to be pressed...", comment: "")
        case .COMMAND_WAITFOR_BUTTON2:
            text = NSLocalizedString("Waiting for Button 2 to be pressed...", comment: "")
        case .COMMAND_WAITFOR_BUTTON3:
            text = NSLocalizedString("Waiting for Button 3 to be pressed...", comment: "")
            
        case .COMMAND_GET_SENSOR_FRONT:
            text = NSLocalizedString("Checking front sensor...", comment: "")
        case .COMMAND_GET_SENSOR_REAR:
            text = NSLocalizedString("Checking rear sensor...", comment: "")
            
        case .FEEDBACK_WAITFOR_CLAP:
            text = NSLocalizedString("Ooo, I hear a clap!", comment: "")
        case .FEEDBACK_WAITFOR_OBSTACLE_FRONT:
            text = NSLocalizedString("Ooh, there's something in front of me!", comment: "")
        case .FEEDBACK_WAITFOR_OBSTACLE_REAR:
            text = NSLocalizedString("Ooh, there's something behind me!", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON1:
            text = NSLocalizedString("Feels like a Button 1 press!", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON2:
            text = NSLocalizedString("Feels like a Button 2 press!", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON3:
            text = NSLocalizedString("Feels like a Button 3 press!", comment: "")
        case .FEEDBACK_FAIL:
            text = NSLocalizedString("Uh oh...something's wrong.\nCheck your code!", comment: "")
        case .FEEDBACK_SUCCESS:
            text = ""
            
        case .COMMAND_IDLE:
            text = NSLocalizedString("Waiting to start!", comment: "")
        case .COMMAND_DISCONNECT:
            text = NSLocalizedString("Waiting to connect. Press the \"Connect Dash\" button.", comment: "")
            
        default:
            break
        }
        return text
    }
    
    public static func commandTypeToAccessibilityText(_ text:String)->String{
        if(text == ""){
            return ""
        }
        let type:CommandType = CommandType(rawValue: text)!
        return self.commandTypeToAccessibilityText(type)
    }
    
    public static func commandTypeToAccessibilityText(_ type:CommandType)->String{
        var text:String = ""
        switch(type) {
            
        case .COMMAND_MOVE_FORWARD:
            text = NSLocalizedString("Dash moving forward", comment: "")
        case .COMMAND_MOVE_BACKWARD:
            text = NSLocalizedString("Dash moving backward", comment: "")
        case .COMMAND_TURN_RIGHT:
            text = NSLocalizedString("Dash turning right", comment: "")
        case .COMMAND_TURN_LEFT:
            text = NSLocalizedString("Dash turning left", comment: "")
            
        case .COMMAND_LIGHT_GREEN:
            text = NSLocalizedString("Green lights on!", comment: "")
        case .COMMAND_LIGHT_YELLOW:
            text = NSLocalizedString("Yellow lights on!", comment: "")
        case .COMMAND_LIGHT_RED:
            text = NSLocalizedString("Red lights on!", comment: "")
        case .COMMAND_LIGHT_WHITE:
            text = NSLocalizedString("White lights on!", comment: "")
        case .COMMAND_LIGHT_BLUE:
            text = NSLocalizedString("Blue lights on!", comment: "")
            
        case .COMMAND_SOUND_ENGINE:
            text = NSLocalizedString("Playing engine sound", comment: "")
        case .COMMAND_SOUND_HI:
            text = NSLocalizedString("Dash says \"Hi!\"", comment: "")
        case .COMMAND_SOUND_AWESOME:
            text = NSLocalizedString("Dash says \"Awesome!\"", comment: "")
        case .COMMAND_SOUND_FANTASTIC:
            text = NSLocalizedString("Dash says \"Fantastic!\"", comment: "")
        case .COMMAND_SOUND_OHNO:
            text = NSLocalizedString("Dash says \"Oh no!\"", comment: "")
        case .COMMAND_SOUND_WHA:
            text = NSLocalizedString("Dash says \"Wha!\"", comment: "")
        case .COMMAND_SOUND_BRAGGING:
            text = NSLocalizedString("Playing Bragging sound", comment: "")
        case .COMMAND_SOUND_HEREICOME:
            text = NSLocalizedString("Dash says \"Here I come!\"", comment: "")
        case .COMMAND_SOUND_INTERESTING:
            text = NSLocalizedString("Dash says \"Interesting!\"", comment: "")
        case .COMMAND_SOUND_INPUTSOUTPUTS:
            text = NSLocalizedString("Dash says \"Inputs & Outputs!\"", comment: "")
        case .COMMAND_SOUND_HORN:
            text = NSLocalizedString("Playing horn sound", comment: "")
            
        case .COMMAND_WAITFOR_OBSTACLE_FRONT:
            text = NSLocalizedString("Waiting for obstacle in front", comment: "")
        case .COMMAND_WAITFOR_OBSTACLE_REAR:
            text = NSLocalizedString("Waiting for obstacle behind", comment: "")
        case .COMMAND_WAITFOR_CLAP:
            text = NSLocalizedString("Waiting for a clap sound", comment: "")
        case .COMMAND_WAITFOR_BUTTON1:
            text = NSLocalizedString("Waiting for Button 1 to be pressed", comment: "")
        case .COMMAND_WAITFOR_BUTTON2:
            text = NSLocalizedString("Waiting for Button 2 to be pressed", comment: "")
        case .COMMAND_WAITFOR_BUTTON3:
            text = NSLocalizedString("Waiting for Button 3 to be pressed", comment: "")
            
        case .COMMAND_GET_SENSOR_FRONT:
            text = NSLocalizedString("Checking front sensor", comment: "")
        case .COMMAND_GET_SENSOR_REAR:
            text = NSLocalizedString("Checking rear sensor", comment: "")
            
        case .FEEDBACK_WAITFOR_CLAP:
            text = NSLocalizedString("Clap sound detected", comment: "")
        case .FEEDBACK_WAITFOR_OBSTACLE_FRONT:
            text = NSLocalizedString("Detected", comment: "")
        case .FEEDBACK_WAITFOR_OBSTACLE_REAR:
            text = NSLocalizedString("Detected", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON1:
            text = NSLocalizedString("Detected", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON2:
            text = NSLocalizedString("Detected", comment: "")
        case .FEEDBACK_WAITFOR_BUTTON3:
            text = NSLocalizedString("Detected", comment: "")
        case .FEEDBACK_FAIL:
            text = NSLocalizedString("Something is wrong, check your code", comment: "")
        case .FEEDBACK_SUCCESS:
            text = "Successfully completed!"
            
        case .COMMAND_IDLE:
            text = NSLocalizedString("Waiting to start!", comment: "")
        case .COMMAND_DISCONNECT:
            text = NSLocalizedString("Waiting to connect. Press the \"Connect Dash\" button.", comment: "")
            
        default:
            break
        }
        return text
    }
    
    public static let LIVEVIEW_DESCRIPTIONS:[String] = [
        NSLocalizedString("Page 1: Dash is on the street.", comment: ""),
        NSLocalizedString("Page 1: Dash is on the street.", comment: "")
    ]
    
    // TODO: create an animation manager
    public static let FEEDBACK_WAITFOR_CLAP:[UIImage] = [
        #imageLiteral(resourceName: "feedback_waitForClap01.png"), //# imageLiteral(resourceName: "feedback_waitForClap01.png")
        #imageLiteral(resourceName: "feedback_waitForClap02.png"), //# imageLiteral(resourceName: "feedback_waitForClap02.png")
        #imageLiteral(resourceName: "feedback_waitForClap03.png"), //# imageLiteral(resourceName: "feedback_waitForClap03.png")
        #imageLiteral(resourceName: "feedback_waitForClap04.png"), //# imageLiteral(resourceName: "feedback_waitForClap04.png")
    ]
    
    public static let FEEDBACK_WAITFOR_CLAP_PORTRAIT:[UIImage] = [
        #imageLiteral(resourceName: "feedback_waitForClap01_portrait.png"), //# imageLiteral(resourceName: "feedback_waitForClap01_portrait.png")
        #imageLiteral(resourceName: "feedback_waitForClap02_portrait.png"), //# imageLiteral(resourceName: "feedback_waitForClap02_portrait.png")
        #imageLiteral(resourceName: "feedback_waitForClap03_portrait.png"), //# imageLiteral(resourceName: "feedback_waitForClap03_portrait.png")
        #imageLiteral(resourceName: "feedback_waitForClap04_portrait.png"), //# imageLiteral(resourceName: "feedback_waitForClap04_portrait.png")
    ]
    
    public static let COMMAND_IDLE:[UIImage] = [
        #imageLiteral(resourceName: "command_idle01"), //# imageLiteral(resourceName: "command_idle01")
        #imageLiteral(resourceName: "command_idle02"), //# imageLiteral(resourceName: "command_idle02")
    ]
    
    public static let COMMAND_IDLE_PORTRAIT:[UIImage] = [
        #imageLiteral(resourceName: "command_idle01_portrait"), //# imageLiteral(resourceName: "command_idle01_portrait")
        #imageLiteral(resourceName: "command_idle02_portrait"), //# imageLiteral(resourceName: "command_idle02_portrait")
    ]
    
    public static let COMMAND_DISCONNECT:[UIImage] = [
        #imageLiteral(resourceName: "command_disconnect01"), //# imageLiteral(resourceName: "command_disconnect01")
        #imageLiteral(resourceName: "command_disconnect02"), //# imageLiteral(resourceName: "command_disconnect02")
        #imageLiteral(resourceName: "command_disconnect03"), //# imageLiteral(resourceName: "command_disconnect03")
        #imageLiteral(resourceName: "command_disconnect04"), //# imageLiteral(resourceName: "command_disconnect04")
        #imageLiteral(resourceName: "command_disconnect05"), //# imageLiteral(resourceName: "command_disconnect05")
    ]
    
    public static let COMMAND_DISCONNECT_PORTRAIT:[UIImage] = [
        #imageLiteral(resourceName: "command_disconnect01_portrait"), //# imageLiteral(resourceName: "command_disconnect01_portrait")
        #imageLiteral(resourceName: "command_disconnect02_portrait"), //# imageLiteral(resourceName: "command_disconnect02_portrait")
        #imageLiteral(resourceName: "command_disconnect03_portrait"), //# imageLiteral(resourceName: "command_disconnect03_portrait")
        #imageLiteral(resourceName: "command_disconnect04_portrait"), //# imageLiteral(resourceName: "command_disconnect04_portrait")
        #imageLiteral(resourceName: "command_disconnect05_portrait"), //# imageLiteral(resourceName: "command_disconnect05_portrait")
    ]
    
    public static let COMMAND_WAITFOR_CLAP:[UIImage] = [
        #imageLiteral(resourceName: "command_waitForClap01"), //# imageLiteral(resourceName: "command_waitForClap01")
        #imageLiteral(resourceName: "command_waitForClap02"), //# imageLiteral(resourceName: "command_waitForClap02")
        #imageLiteral(resourceName: "command_waitForClap03"), //# imageLiteral(resourceName: "command_waitForClap03")
        #imageLiteral(resourceName: "command_waitForClap04"), //# imageLiteral(resourceName: "command_waitForClap04")
    ]
    
    public static let COMMAND_WAITFOR_CLAP_PORTRAIT:[UIImage] = [
        #imageLiteral(resourceName: "command_waitForClap01_portrait"), //# imageLiteral(resourceName: "command_waitForClap01_portrait")
        #imageLiteral(resourceName: "command_waitForClap02_portrait"), //# imageLiteral(resourceName: "command_waitForClap02_portrait")
        #imageLiteral(resourceName: "command_waitForClap03_portrait"), //# imageLiteral(resourceName: "command_waitForClap03_portrait")
        #imageLiteral(resourceName: "command_waitForClap04_portrait"), //# imageLiteral(resourceName: "command_waitForClap04_portrait")
    ]
    
    public static func isProtectedName(_ name:String)->Bool{
        return (name.caseInsensitiveCompare(PROTECTED_NAME1) == ComparisonResult.orderedSame) || (name.caseInsensitiveCompare(PROTECTED_NAME2) == ComparisonResult.orderedSame)
    }
}
