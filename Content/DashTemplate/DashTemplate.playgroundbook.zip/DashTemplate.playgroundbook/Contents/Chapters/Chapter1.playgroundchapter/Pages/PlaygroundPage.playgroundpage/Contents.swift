//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), moveBackward(), turnLeft(), turnRight(), waitForObstacleInFront(), waitForObstacleInRear(), waitForButton1Press(), waitForButton2Press(), waitForButton3Press(), waitForClap(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo, setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
//#-end-hidden-code

//#-editable-code Tap to enter code
//#-end-editable-code

//#-hidden-code
exitProgram()
//#-end-hidden-code
