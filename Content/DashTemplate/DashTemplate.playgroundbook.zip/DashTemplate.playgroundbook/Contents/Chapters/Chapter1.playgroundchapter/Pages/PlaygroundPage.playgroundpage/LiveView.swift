import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


let robotViewController:RobotViewController = RobotViewController(1)
PlaygroundPage.current.liveView = robotViewController
